#apresentação
print('Olá! Seja bem vindo a loja de Açai e Cupuaçu do José Lima A. Filho') 

print("--------------------------------------------")
print("------------------Cardápio------------------")
print("--------------------------------------------")
print("---| Tamanho | Cupuaçu (CP) | Acaí (AC) |---")
print("---|    P    |   R$ 9.00    |  R$ 11.00 |---")
print("---|    M    |   R$ 14.00   |  R$ 16.00 |---")
print("---|    G    |   R$ 18.00   |  R$ 20.00 |---")
print("--------------------------------------------")
print("--------------------------------------------")

valor  = 0
#para iniciar o loop
while True:

    #para o cliente informar se quer o copuaçu ou o açaí
    produto= input('Qual produto você deseja: Cupuaçu(CP) ou Açaí (AC)')
    if (produto!= 'CP' and produto!='AC'):     
        print('Sabor inválido. Favor tente novamente') #para quando o usuario errar
        continue #para o cliente fazer o pedido novamente

   #para o cliente informar o tamanho 
    tamanho= input('Qual tamanho você deseja (P/M/G):')
    if (tamanho!= 'P' and tamanho!='M' and tamanho!='G'):
        print("O tamanho inválido. Favor tente novamente.")
        continue #para o cliente fazer o pedido novamente
   
    if (produto == 'CP' and tamanho == 'P'):
        valor += 9 #Para somar os valores
        print('Você escolheu Cupuaçu no tamanho P R$ 9.00')
    
    elif(produto == 'CP' and tamanho == 'M'):
        valor += 14
        print('Você escolheu Cupuaçu no tamanho M R$ 14.00')

    elif(produto == 'CP' and tamanho == 'G'):
        valor += 18
        print('Você escolheu Cupuaçu no tamanho G R$ 18.00')

    elif(produto == 'AC' and tamanho == 'P'):
        valor += 11
        print('Você escolheu Açaí no tamanho P R$ 11.00')

    elif(produto == 'AC' and tamanho == 'M'):
        valor += 16
        print('Você escolheu Açaí no tamanho M R$ 16.00')

    elif(produto == 'AC' and tamanho == 'G'):
        valor += 20
        print('Você escolheu Açaí no tamanho G R$ 20.00')  

    final= input('Deseja mais alguma coisa? (S/N)')
    if (final == 'S'):
        continue # Se o cliente deseja pedir mais alguma coisa retorna ao inicio
    else:
        print(f'Total a ser pago R${valor}')
        break #Se digita N finaliza e mostra o valor total a ser pago




    
        