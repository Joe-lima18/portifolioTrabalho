print("Bem vinda a Copiadora do José Lima A. Filho")
print('')


servico= input('informe o serviço deseja')
print('DIG- Digitalização')
print('ICO- Impressão colorida')
print('IPB- Impressão preto e branco')
print('FTO- Fotocópia')

