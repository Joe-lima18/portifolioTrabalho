#apresentação inicial
print('Bem vindo a loja do José Lima A. Filho')

#variantes para pedir valor e quantidade
valorProduto= float(input('Informe o valor do produto: R$'))
qtd= int(input('Informe a quantidade pedida:'))

#•	Se valor for menor que 2500 o desconto será de 0%;
#•	Se valor for igual ou maior que 2500 e menor que 6000 o desconto será de 4%;
#•	Se valor for igual ou maior que 6000 e menor que 10000 o desconto será de 7%;
#•	Se valor for igual ou maior que 10000 o desconto será de 11%;

# para achar o valor depois de inserida as quantidades
valor= valorProduto * qtd

print(f'Valor sem desconto R${valor}')

#desconto de 4%
if( 2500<=valor<6000 ):
    desconto = valor * 0.04
    valorTotal= valor - desconto
    print(f'O valor da compra terá o desconto de 4%, o valor total com desconto é R${valorTotal}')

#desconto de 7%
elif( 6000<=valor < 10000):
    desconto = valor * 0.07
    valorTotal = valor - desconto
    print(f'O valor da compra terá o desconto de 7%, o valor total com desconto é R${valorTotal}')

#desconto de 11%
elif( valor >= 10000):
    desconto = valor * 0.11
    valorTotal = valor - desconto
    print(f'O valor da compra terá o desconto de 11%, o valor total com desconto é R${valorTotal}')

#sem desconto
else:
    print('o valor informado é menor que R$ 2.500 portanto não receberá desconto')



